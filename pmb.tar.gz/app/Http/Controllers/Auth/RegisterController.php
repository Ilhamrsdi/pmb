<?php

namespace App\Http\Controllers\Auth;

use App\Models\User;
use App\Models\Wali;
use App\Models\Atribut;
use App\Models\Pendaftar;
use App\Models\ProgramStudi;
use App\Mail\EmailNotification;
use App\Models\DetailPendaftar;
use App\Http\Controllers\Controller;
use App\Models\GelombangPendaftaran;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use App\Providers\RouteServiceProvider;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use App\Models\BniEnc;
use App\Models\RefPorgramStudi;
use Illuminate\Support\Facades\Http;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        $validate = Validator::make($data, [
            'nama' => ['required', 'string', 'max:255'],
            'nik' => ['required', 'string', 'max:16'],
            'email' => ['required', 'string', 'email', 'max:255'],
            'avatar' => ['image', 'mimes:jpg,jpeg,png', 'max:1024'],
            'sekolah' => ['required', 'string'],
            'program_studi' => ['required', 'string'],
            'gelombang' => ['required', 'integer'],
        ]);

        return $validate;
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\Models\User
     */
    protected function create(array $data)
    {
        if (request()->has('avatar')) {
            $avatar = request()->file('avatar');
            $avatarName = time() . '.' . $avatar->getClientOriginalExtension();
            $avatarPath = public_path('/images/');
            $avatar->move($avatarPath, $avatarName);
        }

        $user = User::where('nik', $data['nik'])->first();

        if ($user != NULL) {
            $this->userIsNotNull($user, $data);
        } else {
            $user = $this->userIsNull($data);
        }

        session(['gelombang_id' => $data['gelombang']]);

        return $user;
    }

    public function userIsNull(array $data)
    {
        // dd($data);

        // $this->createVA($va, $trx_id);
        $va_bni = $this->createVA($data);
        $cek_pendaftar_va_bni = $this->CekPendaftaranVA($data);
        // dd($cek_pendaftar_va_bni['datetime_expired']);
        $password = rand(100000, 999999);
        $user = User::create([
            'username' => $data['nama'],
            'email' => $data['email'],
            'nik' => $data['nik'],
            'password' => Hash::make($password),
            'avatar' =>   'avatar-1.jpg',
        ]);


        $pendaftar = Pendaftar::create([
            'user_id' => $user->id,
            'nama' => $data['nama'],
            'sekolah' => $data['sekolah'],
            'program_studi_id' => $data['program_studi'],
            'gelombang_id' => $data['gelombang'],
        ]);

        $detailPendaftar = DetailPendaftar::create([
            'pendaftar_id' => $pendaftar->id,
            'kode_bayar' => $password,
            'tanggal_daftar' => now(),
            'va_pendaftaran' => $va_bni['virtual_account'],
            'trx_va' => $va_bni['trx_id'],
            'datetime_expired' => $cek_pendaftar_va_bni['datetime_expired'],
        ]);

        $wali = Wali::create([
            'pendaftar_id' => $pendaftar->id
        ]);

        $atribut = Atribut::create([
            'pendaftar_id' => $pendaftar->id
        ]);

        $program_studi = RefPorgramStudi::find($pendaftar->program_studi_id);
        $gelombang = GelombangPendaftaran::find($pendaftar->gelombang_id);

        $mailData = [
            'title' => 'Mail from PMB Poliwangi',
            'body' => 'Silahkan mengikuti tata cara pendaftaran dan masuk kedalam aplikasi. Mohon menjaga privasi akun masing masing',
            'email' => $user->email,
            'password' => $detailPendaftar->kode_bayar,
            'gelombang' => $gelombang->nama_gelombang . " - " . $gelombang->deskripsi,
            'program_studi' => $program_studi->nama_program_studi
        ];

        Mail::to($user->email)->send(new EmailNotification($mailData));

        return $user;
    }

    public function userIsNotNull($user, array $data)
    {
        $cek_pendaftar = Pendaftar::where('user_id', $user->id)->where('gelombang_id', $data['gelombang'])->first();

        if ($cek_pendaftar != null) {
            redirect('landing');
        } else {
            $data_pendaftar = Pendaftar::where('user_id', $user->id)->with('detailPendaftar')->get();
            // dd($data_pendaftar);
            $pendaftar = Pendaftar::create([
                'user_id' => $user->id,
                'nama' => $data['nama'],
                'sekolah' => $data['sekolah'],
                'program_studi_id' => $data['program_studi'],
                'gelombang_id' => $data['gelombang'],
            ]);

            $detailPendaftar = DetailPendaftar::create([
                'pendaftar_id' => $pendaftar->id,
                'tanggal_daftar' => now(),
                'kode_bayar' => $data_pendaftar[0]->detailPendaftar->kode_bayar
            ]);

            $wali = Wali::create([
                'pendaftar_id' => $pendaftar->id
            ]);

            $atribut = Atribut::create([
                'pendaftar_id' => $pendaftar->id
            ]);

            $program_studi = RefPorgramStudi::find($pendaftar->program_studi_id);
            $gelombang = GelombangPendaftaran::find($pendaftar->gelombang_id);

            $mailData = [
                'title' => 'Mail from PMB Poliwangi',
                'body' => 'Silahkan mengikuti tata cara pendaftaran dan masuk kedalam aplikasi. Mohon menjaga privasi akun masing masing',
                'email' => $user->email,
                'password' => $detailPendaftar->kode_bayar,
                'gelombang' => $gelombang->nama_gelombang . " - " . $gelombang->deskripsi,
                'program_studi' => $program_studi->nama_program_studi
            ];

            Mail::to($user->email)->send(new EmailNotification($mailData));
        }
    }

    public function createVA(array $data)
    {
        //   dd($data['nama']);
        $biaya_pendataran = GelombangPendaftaran::where('id', $data['gelombang'])->first();
        //  dd($biaya_pendataran->nominal_pendaftaran);
        // FROM BNI
        $client_id = '21016';
        $secret_key = '6094ecb0bcb62da963f1b50a876ffe02';
        $url = 'https://apibeta.bni-ecollection.com/';

        //cerate VA
        $data_asli = array(
            'client_id' => $client_id,
            'trx_id' => mt_rand(), // fill with Billing ID
            'trx_amount' => $biaya_pendataran->nominal_pendaftaran,
            'billing_type' => 'c',
            'type' => 'createbilling',
            'datetime_expired' => date('c', time() + 24 * 3600), // billing will be expired in 2 hours
            'virtual_account' => '',
            'customer_name' => $data['nama'],
            'customer_email' => '',
            'customer_phone' => '',
        );
        //cerate VA

        //Cek Pembayaran
        // $data_asli = array(
        // 	'client_id' => $client_id,
        // 	'trx_id' => '1373110458', // fill with Billing ID
        // 	'trx_amount' => '',
        // // 	'billing_type' => 'c',
        // 	'type' => 'inquirybilling',
        // 	'datetime_expired' => '', // billing will be expired in 2 hours
        // 	'virtual_account' => '9882101622121228',
        // 	'customer_name' => '',
        // 	'customer_email' => '',
        // 	'customer_phone' => '',
        // );


        //Cek Pembayaran
        $hashed_string = BniEnc::encrypt(
            $data_asli,
            $client_id,
            $secret_key
        );

        $data = array(
            'client_id' => $client_id,
            'data' => $hashed_string,
        );

        // dd($hashed_string);

        $response = Http::post($url, $data);
        $response_json = json_decode($response, true);
        // dd($response);
        if ($response_json['status'] !== '000') {
            // handling jika gagal
            var_dump($response_json);
        } else {
            $data_response = BniEnc::decrypt($response_json['data'], $client_id, $secret_key);
            // $data_response will contains something like this:
            // array(
            // 	'virtual_account' => 'xxxxx',
            // 	'trx_id' => 'xxx',
            // );
            // 	var_dump($data_response);
            $va = $data_response;
            // $trx_id =  $data_response['trx_id'];
            // dd($trx_id);
        }



        return $va;
    }

    public function CekPendaftaranVA(array $data)
    {
        //   dd($data['nama']);
        $va_bni = $this->createVA($data);
        // FROM BNI
        $client_id = '21016';
        $secret_key = '6094ecb0bcb62da963f1b50a876ffe02';
        $url = 'https://apibeta.bni-ecollection.com/';

        //cerate VA
        // $data_asli = array(
        // 	'client_id' => $client_id,
        // 	'trx_id' => mt_rand(), // fill with Billing ID
        // 	'trx_amount' => 10000,
        // 	'billing_type' => 'c',
        // 	'type' => 'createbilling',
        // 	'datetime_expired' => date('c', time() + 2 * 3600), // billing will be expired in 2 hours
        // 	'virtual_account' => '',
        // 	'customer_name' => $data['nama'],
        // 	'customer_email' => '',
        // 	'customer_phone' => '',
        // );
        //cerate VA

        //Cek Pembayaran
        $data_asli = array(
            'client_id' => $client_id,
            'trx_id' => $va_bni['trx_id'], // fill with Billing ID
            'trx_amount' => '',
            // 	'billing_type' => 'c',
            'type' => 'inquirybilling',
            'datetime_expired' => '', // billing will be expired in 2 hours
            'virtual_account' => $va_bni['virtual_account'],
            'customer_name' => '',
            'customer_email' => '',
            'customer_phone' => '',
        );


        //Cek Pembayaran
        $hashed_string = BniEnc::encrypt(
            $data_asli,
            $client_id,
            $secret_key
        );

        $data = array(
            'client_id' => $client_id,
            'data' => $hashed_string,
        );

        // dd($hashed_string);

        $response = Http::post($url, $data);
        $response_json = json_decode($response, true);
        // dd($response);
        if ($response_json['status'] !== '000') {
            // handling jika gagal
            var_dump($response_json);
        } else {
            $data_response = BniEnc::decrypt($response_json['data'], $client_id, $secret_key);
            // $data_response will contains something like this:
            // array(
            // 	'virtual_account' => 'xxxxx',
            // 	'trx_id' => 'xxx',
            // );
            // 	var_dump($data_response);
            $va = $data_response;
            // $trx_id =  $data_response['trx_id'];
            // dd($va);
        }

        return $va;
    }
}
