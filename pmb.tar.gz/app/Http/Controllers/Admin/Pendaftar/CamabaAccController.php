<?php

namespace App\Http\Controllers\Admin\Pendaftar;

use App\Http\Controllers\Controller;
use App\Models\DetailPendaftar;
use App\Models\GelombangPendaftaran;
use App\Models\Pendaftar;
use App\Models\ProgramStudi;
use App\Models\Wali;
use Illuminate\Http\Request;

class CamabaAccController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        // $camaba_acc = Pendaftar::with('refNegara', 'detailPendaftar')->get();
        $gelombangPendaftaran = GelombangPendaftaran::all();
        $programStudi = ProgramStudi::get();
        $query = Pendaftar::query();
        $query->with('gelombangPendaftaran', 'programStudi', 'detailPendaftar', 'refNegara', 'user')
            ->join('pmb.detail_pendaftars', 'pmb.pendaftars.id', '=', 'pmb.detail_pendaftars.pendaftar_id');
        if ($request->gelombang != '') {
            $query->where('gelombang_id', $request->gelombang);
        }
        if ($request->prodi != '') {
            $query->where('program_studi_id', $request->prodi);
        }
        if ($request->statusacc != '') {
            $query->where('pmb.detail_pendaftars.status_acc', $request->statusacc);
        }
        $camaba_acc = $query->get();
        if ($request->ajax()) {
            $camaba_acc = $query->get();
            return response()->json(['camaba_acc' => $camaba_acc]);
        }
        return view('admin.camaba.camabaAcc', compact('camaba_acc', 'gelombangPendaftaran', 'programStudi'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $camaba_acc = Pendaftar::find($id);
        $detailPendaftar = DetailPendaftar::where('pendaftar_id', $camaba_acc->id)->first();
        $detailPendaftar->status_acc = 'sudah';
        $detailPendaftar->save();
        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $camaba_acc = Pendaftar::find($id);
        $detailPendaftar = DetailPendaftar::where('pendaftar_id', $camaba_acc->id)->first();
        $wali = Wali::where('pendaftar_id', $camaba_acc->id)->first();
        $camaba_acc->delete();
        $detailPendaftar->delete();
        $wali->delete();
        // Alert::success('success', 'Data Berhasil Dihapus');
        return redirect()->back();
    }
}
