<?php

namespace Database\Seeders;

use App\Models\ProgramStudi;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ProdiSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // ProgramStudi::create([
        //     'jurusan_id' => '1',
        //     'kode_program_studi' => '231',
        //     'nama_program_studi' => 'Teknologi Rekayasa Perangkat Lunak',
        //     'jenjang_pendidikan' => 'D4',
        //     'akreditasi' => 'B',
        //     'kode_nim' => '355',
        //     'nomer_urut_nim' => '101',
        //     'status' => 'Aktif'
        // ]);
        // ProgramStudi::create([
        //     'jurusan_id' => '1',
        //     'kode_program_studi' => '231',
        //     'nama_program_studi' => 'Bisnis Digital',
        //     'jenjang_pendidikan' => 'D4',
        //     'akreditasi' => 'B',
        //     'kode_nim' => '355',
        //     'nomer_urut_nim' => '101',
        //     'status' => 'Aktif'
        // ]);
        // ProgramStudi::create([
        //     'jurusan_id' => '2',
        //     'kode_program_studi' => '231',
        //     'nama_program_studi' => 'Teknik Industri',
        //     'jenjang_pendidikan' => 'D4',
        //     'akreditasi' => 'B',
        //     'kode_nim' => '355',
        //     'nomer_urut_nim' => '101',
        //     'status' => 'Aktif'
        // ]);
        // ProgramStudi::create([
        //     'jurusan_id' => '2',
        //     'kode_program_studi' => '231',
        //     'nama_program_studi' => 'Teknologi Rekayasa Manufaktur',
        //     'jenjang_pendidikan' => 'D4',
        //     'akreditasi' => 'B',
        //     'kode_nim' => '355',
        //     'nomer_urut_nim' => '101',
        //     'status' => 'Aktif'
        // ]);
    }
}
