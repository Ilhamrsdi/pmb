<?php

namespace Database\Seeders;

use App\Models\Atribut;
use App\Models\Pendaftar;
use App\Models\Wali;
use Illuminate\Database\Seeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;

class PendaftarSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        Pendaftar::create([
            'user_id' => 1,
            'gelombang_id' => 1,
            'program_studi_id' => 'bbe32aca-5907-4f3a-8ff1-3f427abf62d1',
            'nama' => 'user 1'
        ]);

        Pendaftar::create([
            'user_id' => 2,
            'gelombang_id' => 1,
            'program_studi_id' => 'c5de86f9-c6b4-4740-961b-32da3b1c003a',
            'nama' => 'user 2'
        ]);

        Pendaftar::create([
            'user_id' => 3,
            'gelombang_id' => 1,
            'program_studi_id' => 'bbe32aca-5907-4f3a-8ff1-3f427abf62d1',
            'nama' => 'user 3'
        ]);

        for ($i = 1; $i <= 3; $i++) {
            Atribut::create([
                'pendaftar_id' => $i
            ]);

            Wali::create([
                'pendaftar_id' => $i
            ]);
        }
    }
}
