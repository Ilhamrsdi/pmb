import { key, CustomLocale } from "../types/locale";
declare const l10n: Record<key, CustomLocale>;
export default l10n;
