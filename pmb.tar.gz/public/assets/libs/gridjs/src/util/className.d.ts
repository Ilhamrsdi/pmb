export declare function className(...args: string[]): string;
export declare function classJoin(...classNames: string[]): string;
