export declare function camelCase(str: string): string;
