export declare const allowedParams: string[];
export declare function getParams(obj?: any): {
    params: any;
    passedParams: {};
    rest: {};
};
